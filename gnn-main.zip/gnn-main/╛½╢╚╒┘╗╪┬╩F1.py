# -*- coding: utf-8 -*-
"""
Created on Thu Apr  8 10:02:19 2021

@author: qg
"""

import numpy as np 
from sklearn.metrics import accuracy_score,recall_score,precision_score

from sklearn.tree import DecisionTreeClassifier
y_pred = np.array([0, 1, 2, 0, 1, 2])
y_true = np.array([0, 2, 1, 0, 0, 1])
a = accuracy_score(y_true, y_pred, normalize=False) 
b = recall_score(y_true, y_pred, average='macro') 
c = precision_score(y_true, y_pred, average='macro') 

print('a=',a,'b=',b,'c=',c)