import networkx as nx
#from node2vec import Node2Vec
# 加权图
G = nx.DiGraph()
G.add_weighted_edges_from([(0,1,3.0), (1,2,7.5)]) # 给０１边加权３，　１２边加权７．５
print(G.get_edge_data(1,2))  # 获得１２边的属性

G.add_weighted_edges_from([(2,3,5)], weight='color')
print(G.edges.data())

G.node[1]['size'] = 10
print(G.nodes.data())


import matplotlib.pyplot as plt

g_data = [(1, 2, 6), (1, 3, 1), (1, 4, 5),
          (2, 3, 5),  (2, 5, 3),
          (3, 4, 5), (3, 5, 6), (3, 6, 4), (4, 6, 2),
          (5, 6, 6)]
'''
graph = nx.fast_gnp_random_graph(n=10, p=0.5)#快速随机生成一个无向图
node2vec1 = Node2Vec ( graph, dimensions=64, walk_length=30, num_walks=100, p=0.3,q=0.7,workers=4)#初始化模型
model = node2vec1.fit()#训练模型
print(model.wv.most_similar('2',topn=3))# 观察与节点2最相近的三个节点
'''
